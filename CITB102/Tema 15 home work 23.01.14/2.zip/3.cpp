/***
FN:F00000
PID:3
GID:2
*/

#include <iostream>
#include <string>
#include <vector>

using namespace std;

int main()
{
	//code here

	return 0;
}
